public class HRUser {
}
